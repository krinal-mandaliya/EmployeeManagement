from django.utils import timezone
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from django.contrib import messages
from . models import *
from django.core.paginator import Paginator
from Employee.models import *
from django.db import transaction
from django.utils.dateparse import parse_date
from django.contrib.auth.decorators import login_required

# Create your views here.

# def admin_login(request):
#     try:
#         if request.method == 'POST':
#             username = request.POST.get('username')
#             password = request.POST.get('password')
#             user_obj = User.objects.filter(username=username).first()
            
#             if user_obj is None:
#                 messages.info(request, 'Account not found')
#                 return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
            
#             user_obj = authenticate(username=username, password=password)
            
#             if user_obj is not None:
#                 login(request, user_obj)
#                 if user_obj and user_obj.is_superuser:
#                     return redirect('admin_dashboard')
#             messages.info(request, 'Invalid password. Please try again!!!')
#             return redirect('admin_login')
        
#         return render(request, 'admin/admin_login.html')
    
#     except Exception as e:
#         print(e)
#         return HttpResponse("An error occurred: {}".format(e))

def admin_login(request):
    try:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user_obj = User.objects.filter(username=username).first()
            
            if user_obj is None:
                messages.info(request, 'Account not found')
                return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
            
            user_obj = authenticate(username=username, password=password)
            
            if user_obj is not None:
                login(request, user_obj)
                if user_obj and user_obj.is_superuser:
                    return redirect('dashboard')
                elif user_obj and user_obj.is_authenticated:
                    return HttpResponseRedirect('/Employee/emp_dashboard')
                    
            messages.info(request, 'Invalid password. Please try again!!!')
            return redirect('admin_login')
        
        return render(request, 'admin/admin_login.html')
    
    except Exception as e:
        print(e)
        return HttpResponse("An error occurred: {}".format(e))

@login_required(login_url='')
def dashboard(request):
    emp_data = EmployeeDetail.objects.all()
    today = timezone.now().date() 
    l=LeaveApply.objects.filter(apply_date__date=today).count()
    context = {
        'total_emp' : EmployeeDetail.objects.count(),
        'total_leave' : LeaveApply.objects.count(),
        'total_salary' : sum(emp.salary for emp in emp_data),
        'leave_count':l

        
    }
   
    return render(request, "admin/admin_dashboard.html", context)

@login_required(login_url='')
def add_employee(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        ename = request.POST.get('ename')
        doj = request.POST.get('doj')
        department = request.POST.get('department')
        cv = request.FILES.get('cv')
        emp_img = request.FILES.get('emp_img')
        dob = request.POST.get('dob')
        email = request.POST.get('email')
        contect_no = request.POST.get('contect_no')
        address = request.POST.get('address')
        salary = request.POST.get('salary')
        if EmployeeDetail.objects.filter(email=email).exists():
            messages.error(request,"This email is already in use. Please try another email......")
        if EmployeeDetail.objects.filter(contect_no=contect_no).exists():
            messages.error(request,"This contect number is already in use. Please try another contact number......")

        with transaction.atomic():  # to save all data at once in both table
                # Create the User object
                myuser = User.objects.create_user(username=username, password=password)
                
                # Create the EmployeeData object
                EmployeeDetail.objects.create(
                    user = myuser,
                    ename=ename,
                    doj=doj,
                    department=department,
                    cv=cv,
                    emp_img=emp_img,
                    dob=dob,
                    email=email,
                    contect_no=contect_no,
                    address=address,
                    salary = salary,
                )
         
        messages.success(request, "Employee detail added successfully!!!!!!")
        return redirect('all_emp')
    else:
        return render(request,'admin/add_employee.html')

@login_required(login_url='')
def admin_logout(request):
    logout(request)
    messages.success(request, "Logout successfully......")
    return render(request, "admin/admin_login.html")
    
@login_required(login_url='')
def all_emp(request):
    employees = EmployeeDetail.objects.all()
    p = Paginator(employees, 1)  
    page_no = request.GET.get('page')
    final_data = p.get_page(page_no)
    return render(request, 'admin/all_emp.html',{'final_data': final_data})

@login_required(login_url='')
def delete_emp(request, id):
    employee = get_object_or_404(EmployeeDetail, id=id)
    employee.delete()
    return redirect('all_emp')

@login_required(login_url='')
def edit_employee(request,id):
    employee = get_object_or_404(EmployeeDetail, id=id)
    if request.method == 'POST':
        ename = request.POST.get('ename')
        doj = request.POST.get('doj')
        department = request.POST.get('department')
        cv = request.FILES.get('cv')
        emp_img = request.FILES.get('emp_img')
        dob = request.POST.get('dob')
        email = request.POST.get('email')
        contect_no = request.POST.get('contect_no')
        address = request.POST.get('address')
        salary = request.POST.get('salary')

        if ename:
            employee.ename = ename
        if doj:
            employee.doj = parse_date(doj)
        if department:
            employee.department = department
        if cv:
            employee.cv = cv
        if emp_img:
            employee.emp_img = emp_img
        if dob:
            employee.dob = parse_date(dob)
        if email:
            employee.email = email
        if contect_no:
            employee.contect_no = contect_no
        if address:
            employee.address = address
        if salary:
            employee.salary = salary

        employee.save()
        return redirect('all_emp')
        
    return render(request, 'admin/edit_employee.html',{'employee': employee})

@login_required(login_url='')
def show_leave(request):
    # return render(request, 'admin')
    pass

def leave_request(request):
    leave_requests = LeaveApply.objects.all().order_by('-apply_date')
    
    # Set up pagination, showing 2 items per page
    p = Paginator(leave_requests, 2)
    
    # Get the current page number from the request
    page_no = request.GET.get('page')
    
    # Get the page of data for the current page number
    final_data = p.get_page(page_no)
    
    # Render the template with the paginated data
    return render(request, 'admin/leave_request.html', {'final_data': final_data})

def update_leave_status(request, request_id, status):
    leave_request = get_object_or_404(LeaveApply, id=request_id)
    leave_request.status = status
    leave_request.save()
    return redirect('leave_request')

@login_required(login_url='')
def leave_notification(request):
    today = timezone.now().date()
    leave_count = LeaveApply.objects.filter(apply_date = today).count()
    print(leave_count,'')
    return render(request, 'admin/admin_dashboard.html', {'leave_count': leave_count})