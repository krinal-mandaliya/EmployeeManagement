from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class EmployeeDetail(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    ename = models.CharField(max_length=100)
    doj = models.DateField(auto_now=True)
    department = models.CharField(max_length=100)
    cv = models.FileField(upload_to='cv/')
    emp_img = models.ImageField(upload_to='emp_img/')
    dob = models.DateField(null=True)
    email = models.EmailField(max_length=256)
    contect_no = models.IntegerField()
    address = models.CharField(max_length=256, null=True, blank=True)
    salary = models.IntegerField(default=False)

    def __str__(self):
        return f"{self.user.username} - {self.ename} - {self.department}"
    
    class Meta: 
        db_table = 'EmployeeData'