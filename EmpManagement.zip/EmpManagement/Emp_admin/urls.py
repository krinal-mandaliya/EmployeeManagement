from django.urls import path
from Emp_admin.views import *
from Emp_admin import views

urlpatterns = [
    path('dashboard', views.dashboard, name="dashboard"),
    path('', views.admin_login, name="admin_login"),
    path('add_employee', views.add_employee, name="add_employee"),
    path('admin_logout', views.admin_logout, name="admin_logout"),
    path('leave_notification/', leave_notification, name='leave_notification'),
    path('all_emp', views.all_emp, name="all_emp"),
    path('delete_emp/<int:id>/', views.delete_emp, name="delete_emp"),
    path('edit_employee/<int:id>', views.edit_employee, name="edit_Employee"),
    path('show_leave', views.show_leave, name="show_leave"),
    path('leave_request', views.leave_request, name="leave_request"),
    path('update_leave_status/<int:request_id>/<str:status>/', views.update_leave_status, name="update_leave_status"),
]