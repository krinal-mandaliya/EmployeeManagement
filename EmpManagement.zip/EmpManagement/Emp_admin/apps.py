from django.apps import AppConfig


class EmpAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Emp_admin'
