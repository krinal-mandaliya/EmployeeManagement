from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class LeaveApply(models.Model):
    days= [
        ('singleday', 'single day'),
        ('multipleday', 'multiple day')
    ]
    status_option = {
        1: 'pending',
        2: 'accepted',
        3: 'rejected'
    }
    status_option_choices = [(key, value) for key, value in status_option.items()]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    reason = models.CharField(max_length=256)
    total_days = models.CharField(max_length=20, choices=days)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    apply_date = models.DateTimeField(auto_now_add= True)
    status = models.CharField(max_length=20, choices=status_option_choices, default=status_option[1])

    def __str__(self):
        return f"{self.user.username} "
    
    class Meta:
        db_table = 'LeaveApply'