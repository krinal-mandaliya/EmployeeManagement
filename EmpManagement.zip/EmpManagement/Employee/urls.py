from django.urls import path
from Employee.views import *
from Employee import views

urlpatterns = [
    path('emp_dashboard', views.emp_dashboard, name="emp_dashboard"),
    path('emp_logout', views.emp_logout, name="emp_logout"),
    path('my_profile', views.my_profile, name="my_profile"),
    path('edit_emp/<int:id>', views.edit_emp, name="edit_emp"),
    path('leave_apply/<int:id>', views.leave_apply, name="leave_apply"),
    path('leave_history', views.leave_history, name="leave_history")
]