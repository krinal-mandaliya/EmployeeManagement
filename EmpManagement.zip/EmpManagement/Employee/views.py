from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth import logout
from django.contrib import messages
from Emp_admin.models import *
from Employee.models import *
from datetime import date, timedelta
from django.utils.dateparse import parse_date
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator

# Create your views here.

def emp_dashboard(request):
    today = date.today()
    first_day_of_month = today.replace(day=1)
    if today.month == 12:
        last_day_of_month = today.replace(year=today.year + 1, month=1, day=1) - timedelta(days=1)
    else:
        last_day_of_month = today.replace(month=today.month + 1, day=1) - timedelta(days=1)

    leaves_this_month = LeaveApply.objects.filter(user=request.user).filter(
        start_date__gte=first_day_of_month, start_date__lte=last_day_of_month
    ) | LeaveApply.objects.filter(user=request.user).filter(
        end_date__gte=first_day_of_month, end_date__lte=last_day_of_month
    ) | LeaveApply.objects.filter(user=request.user).filter(
        start_date__lte=first_day_of_month, end_date__gte=last_day_of_month
    )


    total_this_month_leave = 0
    for leave in leaves_this_month:
        if leave.total_days == 'singleday':
            total_this_month_leave += 1
        elif leave.total_days == 'multipleday' and leave.end_date:
            total_this_month_leave += (leave.end_date - leave.start_date).days + 1

    total_leaves_till_date = 0
    all_leaves = LeaveApply.objects.filter(user=request.user)
    for leave in all_leaves:
        if leave.total_days == 'singleday':
            total_leaves_till_date += 1
        elif leave.total_days == 'multipleday' and leave.end_date:
            total_leaves_till_date += (leave.end_date - leave.start_date).days + 1

    employee_detail = get_object_or_404(EmployeeDetail, user=request.user)

    context = {
        "total_this_month_leave": total_this_month_leave,
        "total_leaves_till_date": total_leaves_till_date,
        "monthly_salary": employee_detail.salary  
    }
    return render(request, "employee/employee_dashboard.html", context)


@login_required(login_url='')
def emp_logout(request):
    logout(request)
    messages.success(request, "Logged out successfully....!!!!!!")
    return redirect("admin_login")

@login_required(login_url='')
def my_profile(request):
    employee = get_object_or_404(EmployeeDetail, user=request.user)
    return render(request, 'employee/myprofile.html', {'employee': employee})

@login_required(login_url='')
def edit_emp(request, id):
    employee = EmployeeDetail.objects.get(id = id)
    if request.method == 'POST':
        ename = request.POST.get('ename')
        doj = request.POST.get('doj')
        cv = request.FILES.get('cv')
        emp_img = request.FILES.get('emp_img')
        dob = request.POST.get('dob')
        email = request.POST.get('email')
        contect_no = request.POST.get('contect_no')
        address = request.POST.get('address')
        
        if ename:
            employee.ename = ename
        if doj:
            employee.doj = parse_date(doj)
        if cv:
            employee.cv = cv
        if emp_img:
            employee.emp_img = emp_img
        if dob:
            employee.dob = parse_date(dob)
        if email:
            employee.email = email
        if contect_no:
            employee.contect_no = contect_no
        if address:
            employee.address = address
       
        employee.save()
        return redirect('my_profile')
    return render(request, 'employee/edit_emp.html', {'employee': employee})

@login_required(login_url='')
def leave_apply(request, id):
    if request.method == 'POST':
        user = User.objects.get(id = id)
        reason = request.POST.get('reason')
        total_days = request.POST.get('total_days')
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        apply = LeaveApply.objects.create(
            user = user,
            reason = reason,
            total_days = total_days,
            start_date = parse_date(start_date),
            end_date = parse_date(end_date)
        )
        apply.save()
        messages.success(request, "Your request has been send.")
        return redirect('emp_dashboard')
    
    else:
        return render(request, "employee/Leave_apply.html")
    
@login_required(login_url='')
def leave_history(request):
    leave_applications = LeaveApply.objects.filter(user=request.user).order_by('-apply_date')
    p = Paginator(leave_applications, 1)
    page_no = request.GET.get('page')
    final_data = p.get_page(page_no)

    context = {
        'final_data': final_data,
        'user': request.user,
    }
    return render(request, 'employee/leave_history.html', context)